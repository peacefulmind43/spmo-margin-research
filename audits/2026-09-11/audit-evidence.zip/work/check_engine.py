import numpy as np
from auditlib import sim
from spmo_margin.backtest import simulate,Account
from spmo_margin.bootstrap import simulate_paths
rng=np.random.default_rng(43)
worst=0
for lev in [.5,1,1.475,2,3]:
 for period,schedule in [(1,'daily'),(21,'monthly'),(0,'never'),(-1,'band')]:
  for dip in [0,-.005]:
   r=rng.normal(.0003,.017,(3,1000))
   a=sim(r,lev,period=period,dip=dip,band=.1)
   b=simulate_paths(r,lev,.0363,rebalance=schedule,intraday_dip=dip,band=.1)
   for j,key in [(0,'terminal_equity'),(1,'cagr'),(2,'max_drawdown'),(3,'margin_calls'),(4,'interest_paid'),(5,'mean_leverage'),(6,'rebalances')]:
    np.testing.assert_allclose(a[:,j],b[key],rtol=1e-9,atol=1e-9)
    worst=max(worst,float(np.max(abs(a[:,j]-b[key])/np.maximum(1,abs(b[key])))))
   for k in range(3):
    c=simulate(r[k],np.full(1000,.0363),Account(leverage=lev,rebalance=schedule,intraday_dip=dip,band=.1))
    np.testing.assert_allclose(a[k,[0,1,2]],[c['equity'][-1],c['stats']['cagr'],c['stats']['max_drawdown']],rtol=1e-9,atol=1e-9)
print('Engine verified against BOTH originals, 120 paths/configurations; maximum scaled discrepancy',worst)
r=np.array([[-.4,0.]])
print('Ruin scalar',simulate(r[0],np.full(2,.0363),Account(leverage=3))['stats'])
print('Ruin vector',simulate_paths(r,3,.0363))
print('Ruin fast',sim(r,3))
