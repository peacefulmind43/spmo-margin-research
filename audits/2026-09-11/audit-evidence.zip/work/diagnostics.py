from pathlib import Path
import numpy as np,pandas as pd,json,os
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'mpl')
from auditlib import sim,indices
from spmo_margin import data
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments'
frame,_=data.extend_with_factors();meas,_=data.long_only_momentum_history();paths=frame.ret.to_numpy()[indices(len(frame),3000,10080)]
rows=[]
for m in [.25,.3,.4,.5,.75,1.]:
 o=sim(paths,1.475,stress_m=m,stress_dd=-.2,enforce=True)
 rows.append({'stress_requirement':m,'median_cagr':np.median(o[:,1]),'p05_cagr':np.percentile(o[:,1],5),'p_margin_call':np.mean(o[:,3]>0),'dd70':np.mean(o[:,2]<-.7),'median_mdd':np.median(o[:,2]),'median_mean_leverage':np.median(o[:,5]),'ce_annual':np.mean((o[:,0]/100000)**-.5)**(-2/40)-1})
pd.DataFrame(rows).to_csv(OUT/'maintenance_at1475.csv',index=False)
ref=np.load(OUT/'band_wealth0.06.npy')**-.5;ma=ref.mean();records=[]
for b in [.02,.04,.06,.08,.1,.125,.15,.2,.25,.3]:
 x=np.load(OUT/f'band_wealth{b}.npy')**-.5;mx=x.mean()
 d=mx**-.05-ma**-.05
 influence=-.05*mx**-1.05*x+.05*ma**-1.05*ref
 se=influence.std(ddof=1)/np.sqrt(len(x))
 records.append({'band':b,'ce_difference_bp':d*1e4,'ci95_lower_bp':(d-1.96*se)*1e4,'ci95_upper_bp':(d+1.96*se)*1e4})
pd.DataFrame(records).to_csv(OUT/'band_paired_uncertainty.csv',index=False)
print('history correlation',frame.ret.corr(meas.ret),'synthetic fraction',frame.is_synthetic.mean())
for name,f in [('factor',frame),('measured',meas)]:
 r=f.loc['1995-03-31':'2026-06-30','ret'];print('Index-period',name,'CAGR',np.expm1(np.log1p(r).mean()*252),'vol',r.std()*np.sqrt(252))
print('rolling range',pd.read_csv(OUT/'rolling_loadings.csv').iloc[:,1:].agg(['min','max']).to_string())
print('band',pd.DataFrame(records).to_string(index=False))
print('maintenance',pd.DataFrame(rows).to_string(index=False))
# Static research graphic, with coarse/fine discretisation clearly visible.
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(9,5),layout='constrained')
for case,label,color in [('base','Repo assumptions','#223d76'),('withholding30bp','30 bp withholding drag','#557c8b'),('persistent_drift2pct','2 pp persistent drift uncertainty','#bb7933'),('AU_surcharge200bp','IBKR Australia USD surcharge','#aa493f'),('combined_AU_30bp_drift2pct','Combined scenario','#683a76')]:
 t=pd.read_csv(OUT/f'fine_{case}.csv');ce=(-t.u15/2)**(-2/40)-1
 ax.plot(t.leverage,ce*100,label=label,color=color,lw=2)
 i=np.argmax(ce);ax.plot(t.leverage.iloc[i],ce.iloc[i]*100,'o',color=color)
ax.set(xlabel='SPMO exposure / account equity',ylabel='Certainty-equivalent annual return (%)',title='The leverage optimum changes when omitted assumptions are priced')
ax.legend(fontsize=9);ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False)
fig.text(.01,-.04,'40 years • CRRA γ = 1.5 • 3,000 shared paths • 0.025x grid • USD 100,000 • scenarios, not forecasts',fontsize=9)
fig.savefig(ROOT.parent/'outputs'/'leverage-sensitivity.png',dpi=180,bbox_inches='tight')
