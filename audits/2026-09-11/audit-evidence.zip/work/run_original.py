from pathlib import Path
import subprocess, sys, time, json
root=Path(__file__).resolve().parent
repo=root/'spmo-margin-research'
jobs=[('run_analysis',[]),('overfitting_audit',[]),('funding_strategies',[]),('optimise_target',[]),('position_calculator',['--equity','100000'])]
ps=[]
for name,args in jobs:
    f=(root/f'{name}.log').open('w')
    p=subprocess.Popen([sys.executable,str(repo/'scripts'/f'{name}.py'),*args],cwd=repo,stdout=f,stderr=subprocess.STDOUT,env=__import__('os').environ|{'MPLCONFIGDIR':str(root/'mpl')})
    ps.append((name,p,f,time.time()))
for name,p,f,start in ps:
    rc=p.wait(); f.close()
    print(json.dumps({'script':name,'exit':rc,'seconds':time.time()-start}),flush=True)
