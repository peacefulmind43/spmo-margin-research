import numpy as np
from spmo_margin.backtest import Account,simulate
from spmo_margin.bootstrap import simulate_paths
from auditlib import sim
rng=np.random.default_rng(99);r=rng.normal(.0004,.017,(4,1000));bm=rng.uniform(0,.12,r.shape)
for lev in [.5,1.475,3.]:
 for period,schedule in [(1,'daily'),(21,'monthly'),(0,'never'),(-1,'band')]:
  a=sim(r,lev,bm=bm,period=period,band=.1)
  b=simulate_paths(r,lev,bm,rebalance=schedule,band=.1)
  for j,key in [(0,'terminal_equity'),(1,'cagr'),(2,'max_drawdown'),(3,'margin_calls'),(4,'interest_paid'),(6,'rebalances')]:np.testing.assert_allclose(a[:,j],b[key],rtol=1e-9,atol=1e-9)
  for i in range(4):
   s=simulate(r[i],bm[i],Account(leverage=lev,rebalance=schedule,band=.1))
   np.testing.assert_allclose(a[i,[0,1,2]],[s['equity'][-1],s['stats']['cagr'],s['stats']['max_drawdown']],rtol=1e-9,atol=1e-9)
print('Dynamic rate agreement: 48 path/configurations against both Python simulators at 1e-9')
# Analytic one-day maintenance checks, including no margin credit at all.
for m in [.25,.4,.5,.75,1.]:
 for lev in [1.475,2.]:
  a=sim(np.array([[-.2]]),lev,maintenance=m,stress_m=m,period=0)
  s=simulate(np.array([-.2]),np.array([.0363]),Account(leverage=lev,maintenance_margin=m,rebalance='never'))
  np.testing.assert_allclose(a[0,[0,1,2]],[s['equity'][-1],s['stats']['cagr'],s['stats']['max_drawdown']],rtol=1e-9,atol=1e-9)
print('Maintenance extension matches scalar liquidation at 25/40/50/75/100% requirements')
