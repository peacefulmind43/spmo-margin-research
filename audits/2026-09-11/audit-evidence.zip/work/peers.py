from pathlib import Path
import numpy as np,pandas as pd,json
from auditlib import grid,indices,summary
from spmo_margin import data
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments';OUT.mkdir(exist_ok=True)
N=1500;levels=np.round(np.arange(.6,2.401,.1),3)
px={'SPMO':data.load_total_return('SPMO')}
limits={'DWAQ':('2014-02-19','2020-02-14'),'DUDE':('2020-12-29','2023-11-16'),'LETB':('2022-02-08','2023-10-19')}
rows=[]
for ticker in ['MTUM','PDP','QMOM','MMTM','DWAQ','DUDE','LETB']:
 df=pd.read_csv(ROOT/'peer-data'/f'{ticker}.csv',index_col=0,parse_dates=True)
 if ticker in limits:df=df.loc[slice(*limits[ticker])]
 s=df['Adj Close'];s=s[s>0].dropna();s.name='close';px[ticker]=s
 s.to_csv(data.CACHE_DIR/f'px_{ticker}.csv')
 # Dead ETF feeds need primary distribution validation; do not hide the limitation.
 print(ticker,'dividends',df['Dividends'].sum(),'n',len(s),flush=True)
common_start=max(px[t].index.min() for t in ['SPMO','MTUM','PDP','QMOM','MMTM'])
end=data.load_french_factors().index.max()
for ticker in px:
 frame,fit=data.extend_with_factors(ticker)
 idx=indices(len(frame),N,40*252);tab,w=grid(frame.ret.to_numpy()[idx],levels)
 tab.to_csv(OUT/f'peer_{ticker}.csv')
 live=px[ticker].pct_change().dropna().loc[:end]
 common=live.loc[common_start:end] if ticker not in limits else live
 sp=data.load_total_return('SPY').pct_change().reindex(common.index).dropna()
 cagr=lambda x:float(np.expm1(np.log1p(x).mean()*252))
 row={'ticker':ticker,'live_start':str(live.index.min().date()),'live_end':str(live.index.max().date()),'comparison_start':str(common.index.min().date()),'comparison_end':str(common.index.max().date()),'live_cagr':cagr(common),'spy_same_window_cagr':cagr(sp),'beta_market':fit['beta_market'],'beta_momentum':fit['beta_momentum'],'alpha':fit['alpha_annual'],'synth_mu':frame.ret.mean()*252,'synth_sigma':frame.ret.std()*np.sqrt(252),**summary(tab)}
 rows.append(row);pd.DataFrame(rows).to_csv(OUT/'peers_summary.csv',index=False);print(json.dumps(row),flush=True)
 # A second, explicit common-live-period comparison avoids differing fund ages.
 if ticker not in limits:
  old=data.load_total_return
  def limited(name,refresh=False):return px[name].loc[common_start:end] if name in px else old(name,refresh)
  data.load_total_return=limited
  ff,_=data.extend_with_factors(ticker);data.load_total_return=old
  tt,_=grid(ff.ret.to_numpy()[indices(len(ff),N,40*252)],levels)
  tt.to_csv(OUT/f'peer_common_{ticker}.csv')
  print('COMMON',ticker,summary(tt),flush=True)
