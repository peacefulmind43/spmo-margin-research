import requests
from pathlib import Path
p=Path(__file__).resolve().parent
u='https://www.spglobal.com/spdji/en/indices/dividends-factors/sp-500-momentum-index/'
r=requests.get(u,timeout=60);print(r.status_code);(p/'index_page.html').write_text(r.text)
