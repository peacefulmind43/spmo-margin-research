from pathlib import Path
import ctypes, numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parent
lib=ctypes.CDLL(str(ROOT/'fastsim.dylib'))
ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
lib.run.argtypes=[ptr,ptr,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_double,ctypes.c_double,ctypes.c_int,*([ctypes.c_double]*4),ctypes.c_int,*([ctypes.c_double]*2),ptr,*([ctypes.c_double]*2),ptr]
def sim(paths, lev, bm=.0363, eq0=100000., period=21, band=.1, maintenance=.25, stress_m=.25, stress_dd=-2.,enforce=False,surcharge=0.,drag=0.,drift=None,dip=0.,cost=.0002):
    paths=np.ascontiguousarray(paths,dtype=float);n,h=paths.shape
    bm=np.ascontiguousarray(np.asarray(bm,dtype=float));mode=0 if bm.size==1 else (1 if bm.ndim==1 else 2)
    drift=np.ascontiguousarray(np.zeros(n) if drift is None else drift,dtype=float)
    out=np.empty((n,8));lib.run(paths,bm,mode,n,h,float(lev),float(eq0),period,band,maintenance,stress_m,stress_dd,int(enforce),surcharge,drag,drift,dip,cost,out)
    return out
def indices(n,n_paths,horizon,block=21,seed=11):
    rng=np.random.default_rng(seed);starts=rng.integers(0,n-block,size=(n_paths,int(np.ceil(horizon/block))))
    return (starts[:,:,None]+np.arange(block)).reshape(n_paths,-1)[:,:horizon]
def grid(paths,levels=None,**kw):
    if levels is None:levels=np.round(np.arange(.5,2.601,.05),3)
    rows=[];wealth=[]
    for l in levels:
        o=sim(paths,l,**kw);w=o[:,0]/kw.get('eq0',100000.);wealth.append(w)
        with np.errstate(divide='ignore'):
            u1=np.log(w).mean();u15=-2*np.mean(w**-.5);u2=-np.mean(w**-1)
        rows.append(dict(leverage=l,u1=u1,u15=u15,u2=u2,median=np.median(o[:,1]),p05=np.percentile(o[:,1],5),dd70=np.mean(o[:,2]<-.7),ddmed=np.median(o[:,2]),calls=np.mean(o[:,3]>0),interest=np.mean(o[:,4]),meanlev=np.median(o[:,5]),trades=np.median(o[:,6])))
    return pd.DataFrame(rows).set_index('leverage'),np.array(wealth)
def argmax(tab,col):
    return float(tab[col].idxmax())
def summary(tab):
    feasible=tab[tab.dd70<=1/3]
    return {c:argmax(tab,c) for c in ['u1','u15','u2','median','p05']}|{'constrained':argmax(feasible,'median') if len(feasible) else None}
