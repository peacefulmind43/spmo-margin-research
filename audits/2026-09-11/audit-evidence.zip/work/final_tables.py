from pathlib import Path
import numpy as np,pandas as pd,json
from auditlib import sim,indices
from spmo_margin import data
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments'
peers=pd.read_csv(OUT/'peers_summary.csv')
for i,row in peers.iterrows():
 t=row.ticker
 if t in ['DWAQ','DUDE','LETB']:continue
 p=data.load_total_return(t).pct_change().dropna().loc['2015-12-03':'2026-07-31']
 peers.loc[i,'common_live_cagr']=np.expm1(np.log1p(p).mean()*252)
 tb=pd.read_csv(OUT/f'peer_common_{t}.csv')
 peers.loc[i,'common_fit_gamma15']=tb.loc[tb.u15.idxmax(),'leverage']
peers.to_csv(OUT/'peer_comparison_final.csv',index=False)
frame,_=data.long_only_momentum_history();paths=frame.ret.to_numpy()[indices(len(frame),3000,10080)]
records=[]
for band in [.02,.04,.06,.08,.1,.125,.15,.2,.25,.3]:
 o=sim(paths,1.475,period=-1,band=band);ce=np.mean((o[:,0]/1e5)**-.5)**(-2/40)-1
 records.append({'band':band,'measured_ce_annual':ce,'trades':np.median(o[:,6])})
t=pd.DataFrame(records);t['loss_bp_from_best']=(t.measured_ce_annual.max()-t.measured_ce_annual)*1e4;t.to_csv(OUT/'measured_bands_at1475.csv',index=False)
print(t.to_string(index=False))
# Show the boundary-grid issue using the original cash-account conventions above zero.
from spmo_margin.backtest import Account,simulate
from spmo_margin.bootstrap import simulate_paths
f,_=data.extend_with_factors();r=f.ret.to_numpy()[indices(len(f),3000,2520)]
out=[]
for l in [.05,.25,.5,.75,1.]:
 o=sim(r,l);out.append({'lev':l,'p05':np.percentile(o[:,1],5),'median':np.median(o[:,1])})
print('CASH',out);pd.DataFrame(out).to_csv(OUT/'cash_boundary.csv',index=False)
print('zero position original',simulate(np.array([0.]),np.array([.0363]),Account(leverage=0))['stats']['wiped_out'])
