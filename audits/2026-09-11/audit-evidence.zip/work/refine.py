from pathlib import Path
import numpy as np,pandas as pd,json
from scipy.special import ndtri
from auditlib import grid,indices,summary,sim
from spmo_margin import data
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments'
frame,fit=data.extend_with_factors();N=3000;idx=indices(len(frame),N,10080);paths=frame.ret.to_numpy()[idx]
levels=np.round(np.arange(.95,1.601,.025),3)
z=ndtri((np.arange(N)+.5)/N);np.random.default_rng(223).shuffle(z)
results=[]
def run(name,p=paths,levels=levels,**kw):
 tab,w=grid(p,levels,**kw);tab.to_csv(OUT/f'fine_{name}.csv')
 row={'case':name,**summary(tab)};results.append(row);print(json.dumps(row),flush=True)
 o=sim(p,1.475,**kw)
 row.update(ce_annual=float(np.mean((o[:,0]/100000)**-.5)**(-2/(p.shape[1]/252))-1),p05_at1475=float(np.percentile(o[:,1],5)),median_at1475=float(np.median(o[:,1])),dd70_at1475=float(np.mean(o[:,2]<-.7)),calls_at1475=float(np.mean(o[:,3]>0)))
 pd.DataFrame(results).to_csv(OUT/'fine_summary.csv',index=False)
run('base')
run('withholding15bp',drag=.0015)
run('withholding30bp',drag=.003)
run('AU_surcharge200bp',surcharge=.02)
run('persistent_drift2pct',drift=.02*z)
run('persistent_drift3pct',drift=.03*z)
run('combined_AU_30bp_drift2pct',surcharge=.02,drag=.003,drift=.02*z,stress_m=.5,stress_dd=-.2,enforce=True)
run('horizon10_gamma15',p=frame.ret.to_numpy()[indices(len(frame),N,2520)])
ratepaths=frame.bm.to_numpy()[idx]
run('rates_paired',bm=ratepaths)
run('rates_unpaired',bm=ratepaths[np.roll(np.arange(N),N//2)])
run('rates_mean',bm=ratepaths.mean())
run('stress75',stress_m=.75,stress_dd=-.2,enforce=True)
run('p05_horizon10_cash',p=frame.ret.to_numpy()[indices(len(frame),N,2520)],levels=np.arange(0,1.01,.05))
# Actual-dataset annual arithmetic-drift SE: descriptive calibration, not a posterior.
annual=frame.ret.resample('YE').sum();annual=annual.iloc[1:-1]
print('annual arithmetic mean SE',annual.std(ddof=1)/np.sqrt(len(annual)),'n',len(annual),'mean_bm',ratepaths.mean(),flush=True)
