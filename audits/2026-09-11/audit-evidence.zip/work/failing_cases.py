from pathlib import Path
import numpy as np,pandas as pd,json,sys
from spmo_margin import data,backtest,bootstrap
from auditlib import sim,grid,indices,summary
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments'
rows=[]
frame,_=data.extend_with_factors()
for name,start,end in [('GFC','2007-10-01','2009-04-01'),('COVID','2020-02-01','2020-05-01'),('inflation2022','2022-01-01','2023-01-01'),('dotcom','2000-01-01','2003-01-01')]:
 f=frame.loc[start:end]
 for rate_label,rate in [('actual',f.bm.to_numpy()),('freeze_entry',f.bm.iloc[0]),('constant363',.0363),('constant_episode_mean',f.bm.mean())]:
  o=sim(f.ret.to_numpy()[None,:],1.475,bm=rate)[0]
  rows.append(dict(episode=name,rate_case=rate_label,terminal_multiple=o[0]/1e5,mdd=o[2],interest=o[4],entry_rate=f.bm.iloc[0],end_rate=f.bm.iloc[-1],mean_rate=f.bm.mean()))
pd.DataFrame(rows).to_csv(OUT/'rate_crises.csv',index=False)
# Largest-feasible is not constrained growth maximisation when constraint is loose.
paths=frame.ret.to_numpy()[indices(len(frame),3000,10080)]
tab,_=grid(paths,np.round(np.arange(1,2.801,.05),3))
tab.to_csv(OUT/'constraint_failure.csv')
print('Constraint at threshold 1.0: original picks',tab.index.max(),'actual median maximum',tab['median'].idxmax(),flush=True)
# Detect cached-source versus README numerical discrepancies without reauditing known bugs.
print('README benchmark table vs actual ten-year CSV')
print(pd.read_csv(ROOT/'spmo-margin-research/results/bootstrap_high_rates.csv').to_string(index=False))
# Asset-only drawdowns for direct comparison to S&P published index episode figures.
measured,_=data.long_only_momentum_history()
for label,f in [('factor',frame),('measured',measured)]:
 for name,start,end in [('GFC','2007-10-01','2009-04-01'),('dotcom','2000-01-01','2003-01-01')]:
  r=f.loc[start:end,'ret'];p=np.r_[1,np.cumprod(1+r)];print('PROXY DD',label,name,np.min(p/np.maximum.accumulate(p)-1),flush=True)
# Financing and margin cap may not be re-opened immediately after compulsory liquidation.
for m in [.25,.75]:
 a=backtest.simulate(np.zeros(2),np.full(2,.0363),backtest.Account(leverage=1.475,maintenance_margin=m,rebalance='daily'))
 print('Post-liquidation requirement',m,'final held equity fraction',1/1.475,'calls',a['stats']['margin_calls'],flush=True)
