from pathlib import Path
import zipfile,subprocess,hashlib,json,shutil
root=Path(__file__).resolve().parents[1];work=root/'work';out=root/'outputs';repo=work/'spmo-margin-research'
shutil.copy(work/'experiments/fine_summary.csv',out/'experiment-summary.csv')
shutil.copy(work/'experiments/peer_comparison_final.csv',out/'peer-comparison.csv')
manifest={};target=out/'audit-evidence.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 def add(name,content):
  if isinstance(content,Path):content=content.read_bytes()
  z.writestr(name,content);manifest[name]=hashlib.sha256(content).hexdigest()
 add('README.md',work/'BUNDLE_README.md')
 req=(work/'requirements-lock.txt').read_text();req='\n'.join(s for s in req.splitlines() if not s.startswith('-e '))+'\n# Install the editable repository separately as documented.\n'
 add('requirements-lock.txt',req.encode())
 for p in out.iterdir():
  if p.is_file() and p.suffix in ['.md','.png','.patch','.csv']:add('outputs/'+p.name,p)
 for p in work.glob('*.py'):add('work/'+p.name,p)
 add('work/fastsim.cpp',work/'fastsim.cpp')
 for folder in ['experiments','peer-data']:
  for p in (work/folder).iterdir():
   if p.is_file():add('work/'+folder+'/'+p.name,p)
 for p in work.glob('*.log'):add('logs/'+p.name,p)
 for p in (repo/'results').glob('*.csv'):add('logs/original-script-results/'+p.name,p)
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
 for name in tracked:
  if not name or name.startswith('results/figures/'):continue
  content=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo)
  if name in ['spmo_margin/metrics.py','spmo_margin/bootstrap.py','spmo_margin/optimal.py','scripts/optimise_target.py']:content=(repo/name).read_bytes()
  add('work/spmo-margin-research/'+name,content)
 add('work/spmo-margin-research/tests/test_adversarial.py',repo/'tests/test_adversarial.py')
 add('MANIFEST.sha256.json',json.dumps(manifest,indent=2).encode())
print(target,'bytes',target.stat().st_size,'entries',len(manifest)+1)
with zipfile.ZipFile(target) as z:assert z.testzip() is None
