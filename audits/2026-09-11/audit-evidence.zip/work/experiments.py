from pathlib import Path
import numpy as np,pandas as pd,json,time,sys
from spmo_margin import data
from auditlib import grid,indices,summary,sim
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments';OUT.mkdir(exist_ok=True)
N=int(sys.argv[1]) if len(sys.argv)>1 else 1500
YEARS=40
frame,fit=data.extend_with_factors();r=frame.ret.to_numpy();idx=indices(len(r),N,YEARS*252);paths=r[idx]
levels=np.round(np.arange(.6,2.401,.1),3)
records=[]
def run(name,p=paths,**kw):
 t=time.time();tab,w=grid(p,levels,**kw);tab.to_csv(OUT/f'{name}.csv');np.savez_compressed(OUT/f'{name}_wealth.npz',wealth=w,levels=levels)
 row={'case':name,**summary(tab),'seconds':time.time()-t};records.append(row);print(json.dumps(row),flush=True)
 pd.DataFrame(records).to_csv(OUT/'summary.csv',index=False)
 return tab,w
if __name__=='__main__':
 run('base')
 run('withholding15bp',drag=.0015)
 run('withholding30bp',drag=.003)
 run('AU_surcharge200bp',surcharge=.02)
 for m in [.3,.4,.5,.75]:run(f'maintenance{m}',maintenance=m,stress_m=m,enforce=True)
 for m in [.4,.5,.75,1.]:run(f'stress_maintenance{m}',stress_m=m,stress_dd=-.2,enforce=True)
 # Rate-level and timing separated with identical returns and same marginal rate distribution.
 rate=frame.bm.to_numpy();ratepaths=rate[idx]
 run('rates_constant_historical_mean',bm=float(ratepaths.mean()))
 run('rates_paired_historical',bm=ratepaths)
 run('rates_unpaired_historical',bm=ratepaths[np.roll(np.arange(N),N//2)])
 # Center each rate experiment to current mean without truncation changing the comparison.
 centered=ratepaths-ratepaths.mean()+.0363
 run('rates_paired_same_mean',bm=centered)
 run('rates_unpaired_same_mean',bm=centered[np.roll(np.arange(N),N//2)])
 # Annual drift uncertainty is persistent within an investor's entire horizon, not redrawn daily.
 from scipy.special import ndtri
 z=ndtri((np.arange(N)+.5)/N);np.random.default_rng(223).shuffle(z)
 for se in [.01,.02,.03]:run(f'persistent_drift_se{se}',drift=se*z)
 run('combined_30bp_2pct_drift',drag=.003,drift=.02*z,stress_m=.5,stress_dd=-.2,enforce=True)
 # Hold gamma and the simulated first ten years fixed, rather than changing objectives with horizon.
 run('horizon10',p=paths[:,:2520])
 run('horizon20',p=paths[:,:5040])
 # Measured long-only proxy with only fees charged on the synthetic portion.
 measured,_=data.long_only_momentum_history();mr=measured.ret.to_numpy();mi=indices(len(mr),N,YEARS*252)
 run('measured',p=mr[mi])
 fee=mr-measured.is_synthetic.to_numpy()*.0013/252
 run('measured_fee13bp',p=fee[mi])
 # Tail-loss diagnostic on fixed shared 40-year paths.
 for name,kwargs in [('base',{}),('stress75',dict(stress_m=.75,stress_dd=-.2,enforce=True)),('AU',dict(surcharge=.02))]:
  oo=sim(paths,1.475,**kwargs);pd.DataFrame(oo,columns=['equity','cagr','mdd','calls','interest','meanlev','trades','final_equity_ratio']).to_csv(OUT/f'path_detail_{name}.csv',index=False)
 print('fit',fit,flush=True)
