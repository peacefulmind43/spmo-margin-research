from pathlib import Path
import numpy as np,pandas as pd,json
from auditlib import grid,indices,summary,sim
from spmo_margin import data
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'experiments'
N=1500;levels=np.round(np.arange(.6,2.401,.1),3)
frame,fit=data.extend_with_factors();fac=data.load_french_factors();live=data.load_total_return('SPMO').pct_change().dropna()
joined=live.rename('ret').to_frame().join(fac,how='inner').dropna()
X=np.column_stack([np.ones(len(joined)),joined.mkt_rf,joined.mom]);y=(joined.ret-joined.rf).to_numpy()
coefs=[];resids=[];dates=[]
for i in range(250,len(y)):
 b=np.linalg.lstsq(X[i-250:i],y[i-250:i],rcond=None)[0]
 coefs.append(b);resids.append(y[i]-X[i]@b);dates.append(joined.index[i])
b=np.array(coefs);e=np.array(resids);pd.DataFrame(b,index=dates,columns=['alpha','market','momentum']).to_csv(OUT/'rolling_loadings.csv')
synthetic=frame.is_synthetic.to_numpy();n=synthetic.sum();base_mu=frame.ret.to_numpy()[synthetic].mean()
f=fac.reindex(frame.index);rng=np.random.default_rng(903)
rows=[]
for label,block in [('rolling_regimes21',21),('rolling_regimes252',252)]:
 ii=indices(len(e),1,n,block=block,seed=31)[0]
 rr=(f.loc[synthetic,'rf'].to_numpy()+b[ii,1]*f.loc[synthetic,'mkt_rf'].to_numpy()+b[ii,2]*f.loc[synthetic,'mom'].to_numpy()+e[ii])
 # Keep expected return identical: change only the exposure/risk process.
 rr=rr-rr.mean()+base_mu
 full=frame.ret.to_numpy().copy();full[synthetic]=rr
 tab,_=grid(full[indices(len(full),N,10080)],levels);tab.to_csv(OUT/f'{label}.csv')
 row={'case':label,'mu':full.mean()*252,'sigma':full.std()*np.sqrt(252),**summary(tab)};rows.append(row);print(json.dumps(row),flush=True)
for label,sel in [('fit_first_half',np.arange(len(y))<len(y)//2),('fit_second_half',np.arange(len(y))>=len(y)//2)]:
 coef=np.linalg.lstsq(X[sel],y[sel],rcond=None)[0];eps=y[sel]-X[sel]@coef
 ii=indices(len(eps),1,n,seed=20260910)[0];draw=eps[ii];draw-=draw.mean()
 rr=f.loc[synthetic,'rf'].to_numpy()+coef[1]*f.loc[synthetic,'mkt_rf'].to_numpy()+coef[2]*f.loc[synthetic,'mom'].to_numpy()+draw
 full=frame.ret.to_numpy().copy();full[synthetic]=rr
 tab,_=grid(full[indices(len(full),N,10080)],levels);tab.to_csv(OUT/f'{label}.csv')
 row={'case':label,'mu':full.mean()*252,'sigma':full.std()*np.sqrt(252),'beta_market':coef[1],'beta_momentum':coef[2],**summary(tab)};rows.append(row);print(json.dumps(row),flush=True)
pd.DataFrame(rows).to_csv(OUT/'loadings_summary.csv',index=False)
paths=frame.ret.to_numpy()[indices(len(frame),3000,10080)]
# Joint optimisation, and uncertainty on certainty-equivalent annual return differences.
records=[]
for band in [.02,.04,.06,.08,.10,.125,.15,.2,.25,.3]:
 tab,w=grid(paths,np.arange(1.25,1.701,.025),period=-1,band=band)
 tab.to_csv(OUT/f'joint_band{band}.csv');idx=np.argmax(tab.u15);lev=tab.index[idx]
 ref=sim(paths,1.475,period=-1,band=band);np.save(OUT/f'band_wealth{band}.npy',ref[:,0]/100000)
 records.append({'band':band,'joint_leverage':lev,'joint_utility':tab.u15.iloc[idx],'trades':np.median(ref[:,6]),'ce_annual_at1475':np.mean((ref[:,0]/100000)**-.5)**(-2/40)-1})
pd.DataFrame(records).to_csv(OUT/'band_summary.csv',index=False);print('BANDS',records,flush=True)
