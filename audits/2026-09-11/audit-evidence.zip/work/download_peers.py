from pathlib import Path
import yfinance as yf, json
root=Path(__file__).resolve().parent
out=root/'peer-data';out.mkdir(exist_ok=True)
yf.set_tz_cache_location(str(root/'yf-cache'))
for ticker in ['MTUM','PDP','QMOM','MMTM','AMOM','DWAQ','DWLV','DUDE','LETB','FMTM','^SP500MUP']:
    try:
        df=yf.Ticker(ticker).history(period='max',auto_adjust=False,raise_errors=True)
        df.index=df.index.tz_localize(None).normalize()
        df.to_csv(out/f'{ticker.replace("^","idx_")}.csv')
        print(json.dumps({'ticker':ticker,'n':len(df),'start':str(df.index.min()),'end':str(df.index.max())}),flush=True)
    except Exception as e: print(json.dumps({'ticker':ticker,'error':str(e)}),flush=True)
