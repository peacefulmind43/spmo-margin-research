#include <cmath>
#include <algorithm>
extern "C" void run(const double* r, const double* bm, int bm_mode, int n, int h,
 double lev, double eq0, int period, double band, double base_m, double stress_m,
 double stress_dd, int enforce, double surcharge, double drag, const double* drift,
 double dip, double trading_cost, double* out) {
 for(int p=0;p<n;++p){
  double eq=eq0,pos=lev*eq,debit=pos-eq,peak=eq,dd=0,interest=0;
  double asset=1,asset_peak=1,levsum=0; int calls=0,trades=0,days=0;
  for(int t=0;t<h;++t){
   double rate=bm[bm_mode==0?0:(bm_mode==1?t:p*h+t)];
   // Requirements are announced from the prior close's unlevered drawdown.
   double m=(asset/asset_peak-1 < stress_dd)?stress_m:base_m;
   if(debit>0){
    double lo=0,cost=0;
    double up[5]={100000,1000000,50000000,200000000,INFINITY};
    double sp[5]={.015,.01,.0075,.005,.003};
    for(int j=0;j<5;++j){double amt=std::max(std::min(debit,up[j])-lo,0.0);cost+=amt*(std::max(rate+sp[j],.0075)+surcharge);lo=up[j];}
    double accrual=cost/(360.0*252/365);debit+=accrual;interest+=accrual;
   }else if(debit<0){double cash=-debit;debit-=std::max(cash-10000,0.0)*std::max(rate-.005,0.0)/(360.0*252/365);}
   double close=1+r[p*h+t]+drift[p]/252-drag/252,low=std::max(close+dip,1e-9);
   pos*=low;eq=pos-debit;
   if(eq<=0 || (pos<=0 && lev>0)){eq=0;dd=-1;break;}
   if(pos>0 && eq/pos<m){
    double target=eq/m,cost=(pos-target)*.001;eq-=cost;pos=eq/m;debit=pos-eq;++calls;
    if(eq<=0){eq=0;dd=-1;break;}
   }
   pos*=close/low;eq=pos-debit;
   if(eq<=0){eq=0;dd=-1;break;}
   bool due=period>0?(t%period==0):(period==-1 && lev>0 && std::abs(pos/eq/lev-1)>band);
   if(due){
    double targetlev=enforce?std::min(lev,.99/m):lev;
    double cost=std::abs(targetlev*eq-pos)*trading_cost;eq-=cost;pos=targetlev*eq;debit=pos-eq;++trades;
   }
   peak=std::max(peak,eq);dd=std::min(dd,eq/peak-1);levsum+=pos/eq;++days;
   asset*=close;asset_peak=std::max(asset_peak,asset);
  }
  out[p*8]=eq;out[p*8+1]=eq>0?std::pow(eq/eq0,252.0/h)-1:-1;
  out[p*8+2]=dd;out[p*8+3]=calls;out[p*8+4]=interest;
  out[p*8+5]=days?levsum/days:0;out[p*8+6]=trades;out[p*8+7]=pos>0?eq/pos:1;
 }
}
