# Reproducing this audit

The review concerns upstream commit 3b181bfab767f06a72805abd09cd521ed6a7d5da.
The bundled work/spmo-margin-research directory contains that commit's source and
cached inputs, plus the scoped audit patch already applied. Original committed
result tables are included there; logs/original-script-results contains regenerated
tables from the unmodified scripts. The patch is supplied separately too.

From the extracted bundle root, with Python 3.14 and a C++ compiler:

    python3 -m venv .venv
    .venv/bin/python -m pip install -e 'work/spmo-margin-research[dev]'
    .venv/bin/python -m pytest work/spmo-margin-research/tests -q
    clang++ -O3 -ffp-contract=off -shared -fPIC work/fastsim.cpp -o work/fastsim.dylib
    .venv/bin/python work/check_engine.py
    .venv/bin/python work/check_dynamic.py
    .venv/bin/python work/experiments.py 1500
    .venv/bin/python work/peers.py
    .venv/bin/python work/loadings_bands.py
    .venv/bin/python work/failing_cases.py
    .venv/bin/python work/refine.py
    .venv/bin/python work/diagnostics.py
    .venv/bin/python work/final_tables.py

On macOS clang++ was used. On another platform build a shared object with a
compatible C ABI; adjust the library filename in auditlib.py as necessary.
The script still calls it .dylib; ctypes can load an ELF shared library at that
filename if compiled as such on Linux. Do not use fast-math flags.

Exact installed versions are in requirements-lock.txt; the editable-package
absolute path has been replaced with a comment. The repo itself does not pin
versions. Matplotlib font warnings in logs did not prevent execution.

The original commands were run before patching; all five exited successfully.
Original pytest: 117 passed. Patched pytest: 175 passed. New rates retain
scalar/vector agreement at 1e-9. check_engine also verifies the compiled audit
implementation against both simulators. Its printed scalar ruin output differs
after applying the patch; the saved original log preserves the pre-fix failure.

These are audit experiments, not a complete production broker simulator.
Maintenance shocks use the previous close's asset drawdown and cap the subsequent
rebalance target. They do not calibrate IBKR's house rules. Original Python engines
still need admissibility handling before use with raised maintenance targets.
Persistent-drift sensitivities are assumed probability distributions, not fitted
Bayesian posteriors. No transaction was sent to a broker.

Peer caches are retained to avoid relying on mutable downloads. Closed-fund
distribution histories are not verified and are exploratory only. The S&P index
study was used as an external diagnostic; a full daily index return series was
not obtained. Scripts in work/ are audit orchestration, not upstream source.

Report and chart are under outputs/. Raw experiment results are in
work/experiments/. The fine grid was designed to locate gamma-1.5 maxima; other
objective columns can be boundary-truncated and must not be read as global
optima. Broad-grid files provide those comparisons.
